package com.nit.blc;

public class Student {
	
	int rollno;
	String name;
	double height;

	public void talk(){
		System.out.println("My name is:"+name);
		System.out.println("My roll number is:"+rollno);
		System.out.println("My height is :"+height);
	}
	public void behaviour() {
		System.out.println("Hello leaner my name is"+name+"and every saturday i am written exam!!!");
	}

}