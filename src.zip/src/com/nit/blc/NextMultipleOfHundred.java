package com.nit.blc;

public class NextMultipleOfHundred {
	public static int getNextMultipleOfHundred(int num) {
		
		return (num/100+1)*100;	
	}
}
