package com.nit.instanceof_optr;

class Test{
	
}
public class InstanceofDemo1 {

	public static void main(String[] args) {
		Test t1 = new Test();
		if(t1 instanceof Test) {
			System.out.println("ti is pointing to object");
		}
	}

}
