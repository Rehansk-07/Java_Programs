package com.nit.abstraction;

public class ProductStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
