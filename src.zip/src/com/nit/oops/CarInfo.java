package com.nit.oops;

public class CarInfo {

	public static void main(String[] args) {
		Car Ferrari = new Car();
		Ferrari.name = "Ferrari ";
		Ferrari.color = "Voilet";
		Ferrari.model = 24;
		
		Ferrari.getCarInformation();
		Ferrari.drive();
		
		
	}

}
