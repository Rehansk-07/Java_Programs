package com.nit.oops;

public class FanInfo {

	public static void main(String[] args) {
		Fan Bajaj = new Fan();
		Bajaj.name ="Bajaj";
		Bajaj.coil ="copper";
		Bajaj.wings= 3;
		
		Bajaj.switchOn();
		Bajaj.switchOff();
		

	}

}
