package com.nit.oops;

public class Dog {
	
	int age;
	String name;
	double height;
	
 public void getDogInformation() {
	 System.out.println("My Dog name is :"+name);
	 System.out.println("Dog age is :"+age);
	 System.out.println("Dog height is :"+height); 
 }
 public void bark() {
	 System.out.println("My Dog "+name+" and he is always barking ");	 
 }
 
}
