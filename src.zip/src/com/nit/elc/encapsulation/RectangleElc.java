package com.nit.elc.encapsulation;

import java.util.Scanner;

public class RectangleElc {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double rect=Double.parseDouble(sc.nextLine());
		double peri=Double.parseDouble(sc.nextLine());
		
		System.out.println("Hello");
		
	}
}
