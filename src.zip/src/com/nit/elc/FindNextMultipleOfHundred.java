package com.nit.elc;

import com.nit.blc.NextMultipleOfHundred;

public class FindNextMultipleOfHundred {

	public static void main(String[] args) {
		
		int multiple= NextMultipleOfHundred.getNextMultipleOfHundred(123);
		System.out.println(multiple);

	}

}
