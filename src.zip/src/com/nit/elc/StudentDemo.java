package com.nit.elc;

import com.nit.blc.Student;

public class StudentDemo {

	public static void main(String[] args) {
		Student s1 =new Student();
		

	}

}
